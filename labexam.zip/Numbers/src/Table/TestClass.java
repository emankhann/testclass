package Table;

public class TestClass {

    public static boolean isEven(int number) {
        return number % 2 == 0;
    }

    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;  
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;  
            }
        }
        return true;  
    }

    public static void main(String[] args) {
     
        System.out.println("Test Case 1: Check if 4 is even");
        System.out.println(isEven(4)); 

        System.out.println("Test Case 2: Check if 7 is prime");
        System.out.println(isPrime(7)); 

        System.out.println("Test Case 3: Check if 10 is even");
        System.out.println(isEven(10)); 

        System.out.println("Test Case 4: Check if 8 is prime");
        System.out.println(isPrime(8)); 
    }
}